package Polymorphism;

public class Bike extends Vehicle{

	@Override
	void startEngine() {
		System.out.println("Bike is starting..........");
	}
}
