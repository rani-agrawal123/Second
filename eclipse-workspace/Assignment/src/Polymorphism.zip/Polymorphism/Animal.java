package Polymorphism;

public class Animal {

	void makeSound() {
		System.out.println("Animal sound .............");
	}
}
