package Polymorphism;

public class Calculator {
 
	void add(int a, int b) {
		int sum =  a+b;
		System.out.println(sum);
	}
	void add(double a, double b) {
		double sum2 =  a+b;
		System.out.println(sum2);
	}
	void add(int a, int b, int c) {
		int sum3 = a+b+c;
		System.out.println(sum3);
	}
	
	
}
