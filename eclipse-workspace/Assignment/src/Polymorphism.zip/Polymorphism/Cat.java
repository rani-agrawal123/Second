package Polymorphism;

public class Cat extends Animal{

	@Override
	void makeSound() {
		System.out.println("Cat sound is meow........");
	}
}
