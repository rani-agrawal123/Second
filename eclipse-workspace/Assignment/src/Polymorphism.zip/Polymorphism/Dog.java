package Polymorphism;

public class Dog extends Animal{

	@Override
	void makeSound() {
		System.out.println("Dog is barking.......");
	}
}
