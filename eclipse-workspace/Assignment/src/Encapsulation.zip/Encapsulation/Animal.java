package Encapsulation;

public class Animal {

	  String name;
	  String species;
	   void makeSound() {
		   System.out.println("Animal makes a sound");
	   }
}
