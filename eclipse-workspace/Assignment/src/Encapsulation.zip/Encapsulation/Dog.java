package Encapsulation;

public class Dog extends Animal{

	String breed;
	@Override
	void makeSound(){
		System.out.println("Dog barks");
	}
}
