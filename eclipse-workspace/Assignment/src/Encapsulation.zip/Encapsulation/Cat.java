package Encapsulation;

public class Cat extends Animal{
	
	@Override
	void makeSound() {
		System.out.println("Cat meows");
	}

}
